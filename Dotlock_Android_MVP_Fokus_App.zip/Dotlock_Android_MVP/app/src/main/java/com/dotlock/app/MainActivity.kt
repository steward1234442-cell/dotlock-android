package com.dotlock.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101218)
private val Blue = Color(0xFF4388FF)
private val Pale = Color(0xFFF4F6FA)
private val Muted = Color(0xFF697386)

data class Qa(
    val id: String,
    val subject: String,
    val level: String,
    val question: String,
    val working: String,
    val language: String,
    val answer: String = "",
    val keywords: String = ""
)

private val seedQuestions = listOf(
    Qa(
        id = "201", subject = "Matematik", level = "Tingkatan 1",
        question = "Hitung 48 ÷ 6 + 3.",
        working = "Jawapan: 11\n\nIkut tertib operasi: 48 ÷ 6 = 8, kemudian 8 + 3 = 11.",
        language = "BM", answer = "11",
        keywords = "nombor bulat operasi bahagi Nombor bulat"
    ),
    Qa(
        id = "202", subject = "Matematik", level = "Tingkatan 1",
        question = "Hitung 1/2 + 1/4.",
        working = "Jawapan: 3/4\n\nSamakan penyebut: 1/2 = 2/4. Jadi 2/4 + 1/4 = 3/4.",
        language = "BM", answer = "3/4",
        keywords = "pecahan tambah Pecahan"
    ),
    Qa(
        id = "203", subject = "Matematik", level = "Tingkatan 2",
        question = "Cari 15% daripada 200.",
        working = "Jawapan: 30\n\n15/100 × 200 = 30.",
        language = "BM", answer = "30",
        keywords = "peratus Peratus"
    ),
    Qa(
        id = "204", subject = "Matematik", level = "Tingkatan 2",
        question = "Permudahkan 3a + 2a − a.",
        working = "Jawapan: 4a\n\nGabungkan sebutan sejenis: (3 + 2 − 1)a = 4a.",
        language = "BM", answer = "4a",
        keywords = "algebra sebutan sejenis Algebra"
    ),
    Qa(
        id = "205", subject = "Matematik", level = "Tingkatan 3",
        question = "Selesaikan 4x − 7 = 9.",
        working = "Jawapan: x = 4\n\n4x − 7 = 9; 4x = 16; x = 4.",
        language = "BM", answer = "x = 4",
        keywords = "persamaan linear Persamaan linear"
    ),
    Qa(
        id = "206", subject = "Matematik", level = "Tingkatan 3",
        question = "Segi tiga bersudut tegak mempunyai sisi tegak 6 cm dan 8 cm. Cari hipotenus.",
        working = "Jawapan: 10 cm\n\nc² = 6² + 8² = 36 + 64 = 100, maka c = 10 cm.",
        language = "BM", answer = "10 cm",
        keywords = "pythagoras hipotenus Teorem Pythagoras"
    ),
    Qa(
        id = "207", subject = "Matematik", level = "Tingkatan 4",
        question = "Jika f(x) = x² − 3, cari f(4).",
        working = "Jawapan: 13\n\nf(4) = 4² − 3 = 16 − 3 = 13.",
        language = "BM", answer = "13",
        keywords = "fungsi kuadratik Fungsi kuadratik"
    ),
    Qa(
        id = "208", subject = "Matematik", level = "Tingkatan 4",
        question = "Cari kecerunan garis melalui (1, 2) dan (3, 8).",
        working = "Jawapan: 3\n\nm = (8 − 2)/(3 − 1) = 6/2 = 3.",
        language = "BM", answer = "3",
        keywords = "kecerunan garis lurus Kecerunan"
    ),
    Qa(
        id = "209", subject = "Matematik", level = "Tingkatan 5",
        question = "Sebuah dadu adil dilambung sekali. Cari kebarangkalian mendapat nombor genap.",
        working = "Jawapan: 1/2\n\nNombor genap ialah 2, 4, 6: 3 hasil daripada 6. P = 3/6 = 1/2.",
        language = "BM", answer = "1/2",
        keywords = "kebarangkalian dadu Kebarangkalian"
    ),
    Qa(
        id = "210", subject = "Matematik", level = "SPM",
        question = "Permudahkan 2³ × 2⁴.",
        working = "Jawapan: 128\n\nUntuk asas sama, tambah indeks: 2³ × 2⁴ = 2⁷ = 128.",
        language = "BM", answer = "128",
        keywords = "spm indeks Indeks"
    ),
    Qa(
        id = "211", subject = "Mathematics", level = "Form 4",
        question = "Solve x² − 5x + 6 = 0.",
        working = "Jawapan: x = 2 or x = 3\n\nFactorise: (x − 2)(x − 3) = 0. Hence x = 2 or x = 3.",
        language = "EN", answer = "x = 2 or x = 3",
        keywords = "quadratic factorise Quadratic functions"
    ),
    Qa(
        id = "212", subject = "Sains", level = "Tingkatan 1",
        question = "Apakah unit asas bagi semua benda hidup?",
        working = "Jawapan: Sel\n\nSel ialah unit struktur dan fungsi asas organisma hidup.",
        language = "BM", answer = "Sel",
        keywords = "sel organisma Sel"
    ),
    Qa(
        id = "213", subject = "Sains", level = "Tingkatan 2",
        question = "Sebuah objek berjisim 120 g dan isipadu 30 cm³. Hitung ketumpatannya.",
        working = "Jawapan: 4 g/cm³\n\nKetumpatan = jisim ÷ isipadu = 120 ÷ 30 = 4 g/cm³.",
        language = "BM", answer = "4 g/cm³",
        keywords = "ketumpatan jisim isipadu Ketumpatan"
    ),
    Qa(
        id = "214", subject = "Sains", level = "Tingkatan 3",
        question = "Apakah alat untuk mengukur arus elektrik?",
        working = "Jawapan: Ammeter\n\nAmmeter disambung secara siri untuk mengukur arus dalam litar.",
        language = "BM", answer = "Ammeter",
        keywords = "arus elektrik ammeter Elektrik"
    ),
    Qa(
        id = "215", subject = "Sains", level = "Tingkatan 4",
        question = "Apakah yang dimaksudkan dengan gen?",
        working = "Jawapan: Segmen DNA yang membawa maklumat pewarisan.\n\nGen mengandungi maklumat yang mempengaruhi ciri organisma dan diwarisi daripada induk.",
        language = "BM", answer = "Segmen DNA yang membawa maklumat pewarisan.",
        keywords = "genetik dna Genetik"
    ),
    Qa(
        id = "216", subject = "Sains", level = "Tingkatan 5",
        question = "Nyatakan satu cara meningkatkan kadar tindak balas antara pepejal dan larutan.",
        working = "Jawapan: Menambahkan luas permukaan pepejal\n\nMenghancurkan pepejal menjadi kepingan lebih kecil meningkatkan luas permukaan sentuhan dan kadar perlanggaran berkesan.",
        language = "BM", answer = "Menambahkan luas permukaan pepejal",
        keywords = "kadar tindak balas Kadar tindak balas"
    ),
    Qa(
        id = "217", subject = "Sains", level = "SPM",
        question = "Apakah unit SI bagi daya?",
        working = "Jawapan: Newton (N)\n\nDaya diukur dalam newton. Hubungan asas: F = ma.",
        language = "BM", answer = "Newton (N)",
        keywords = "spm daya unit si Daya"
    ),
    Qa(
        id = "218", subject = "Bahasa Melayu", level = "Tingkatan 1",
        question = "Kenal pasti kata kerja dalam ayat: Ali membaca buku.",
        working = "Jawapan: membaca\n\nKata kerja menunjukkan perbuatan; dalam ayat ini, perbuatannya ialah membaca.",
        language = "BM", answer = "membaca",
        keywords = "kata kerja tatabahasa Tatabahasa"
    ),
    Qa(
        id = "219", subject = "Bahasa Melayu", level = "Tingkatan 2",
        question = "Apakah maksud peribahasa 'bagai aur dengan tebing'?",
        working = "Jawapan: Saling membantu antara satu sama lain.\n\nPeribahasa ini menggambarkan hubungan yang saling memerlukan dan bekerjasama.",
        language = "BM", answer = "Saling membantu antara satu sama lain.",
        keywords = "peribahasa Peribahasa"
    ),
    Qa(
        id = "220", subject = "Bahasa Melayu", level = "Tingkatan 3",
        question = "Tukarkan kepada ayat pasif: Ibu memasak nasi.",
        working = "Jawapan: Nasi dimasak oleh ibu.\n\nObjek ayat aktif, 'nasi', menjadi subjek ayat pasif.",
        language = "BM", answer = "Nasi dimasak oleh ibu.",
        keywords = "ayat pasif Ayat"
    ),
    Qa(
        id = "221", subject = "Bahasa Melayu", level = "SPM",
        question = "Nyatakan dua isi untuk karangan tentang amalan membaca.",
        working = "Jawapan: Menambah ilmu pengetahuan; memperkaya kosa kata.\n\nHuraikan setiap isi dengan sebab, contoh yang sesuai dan kesan. Jawapan karangan boleh berbeza jika munasabah.",
        language = "BM", answer = "Menambah ilmu pengetahuan; memperkaya kosa kata.",
        keywords = "spm karangan membaca Karangan"
    ),
    Qa(
        id = "222", subject = "English", level = "Form 1",
        question = "Choose the correct verb: She ___ to school every day. (walk/walks)",
        working = "Jawapan: walks\n\nUse 'walks' with the third-person singular subject 'she' in the simple present tense.",
        language = "EN", answer = "walks",
        keywords = "grammar simple present Grammar"
    ),
    Qa(
        id = "223", subject = "English", level = "Form 3",
        question = "Give a synonym for 'happy'.",
        working = "Jawapan: Glad / joyful\n\nThese words have a similar meaning to 'happy'. Other suitable synonyms may be accepted.",
        language = "EN", answer = "Glad / joyful",
        keywords = "vocabulary synonym Vocabulary"
    ),
    Qa(
        id = "224", subject = "English", level = "SPM",
        question = "Give one suitable opening sentence for an essay about keeping fit.",
        working = "Jawapan: Keeping fit is important because it helps us stay healthy and energetic.\n\nA suitable opening introduces the topic clearly. Students may write other relevant openings.",
        language = "EN", answer = "Keeping fit is important because it helps us stay healthy and energetic.",
        keywords = "spm essay writing Writing"
    ),
    Qa(
        id = "225", subject = "Sejarah", level = "Tingkatan 1",
        question = "Berikan satu contoh sumber sejarah primer.",
        working = "Jawapan: Surat asal / artifak / dokumen sezaman.\n\nSumber primer dihasilkan pada zaman atau oleh pihak yang berkaitan secara langsung dengan peristiwa yang dikaji.",
        language = "BM", answer = "Surat asal / artifak / dokumen sezaman.",
        keywords = "sumber sejarah primer Sumber sejarah"
    ),
    Qa(
        id = "226", subject = "Sejarah", level = "Tingkatan 2",
        question = "Apakah jawatan utama yang membantu sultan mentadbir Kesultanan Melayu Melaka?",
        working = "Jawapan: Bendahara\n\nBendahara ialah pembesar utama yang membantu sultan dalam pentadbiran; peranan pembesar lain juga penting.",
        language = "BM", answer = "Bendahara",
        keywords = "kesultanan melayu melaka bendahara Kesultanan Melayu Melaka"
    ),
    Qa(
        id = "227", subject = "Sejarah", level = "Tingkatan 4",
        question = "Apakah maksud nasionalisme?",
        working = "Jawapan: Perasaan cinta akan bangsa dan negara serta keinginan mempertahankan kedaulatan.\n\nNasionalisme mendorong masyarakat memperjuangkan maruah, identiti dan pemerintahan sendiri.",
        language = "BM", answer = "Perasaan cinta akan bangsa dan negara serta keinginan mempertahankan kedaulatan.",
        keywords = "nasionalisme Nasionalisme"
    ),
    Qa(
        id = "228", subject = "Sejarah", level = "Tingkatan 5",
        question = "Pada tahun berapakah Malaysia dibentuk?",
        working = "Jawapan: 1963\n\nMalaysia dibentuk pada 16 September 1963.",
        language = "BM", answer = "1963",
        keywords = "pembentukan malaysia Pembentukan Malaysia"
    ),
    Qa(
        id = "229", subject = "Sejarah", level = "SPM",
        question = "Pada tarikh berapakah Persekutuan Tanah Melayu mencapai kemerdekaan?",
        working = "Jawapan: 31 Ogos 1957\n\nKemerdekaan diisytiharkan pada 31 Ogos 1957.",
        language = "BM", answer = "31 Ogos 1957",
        keywords = "spm kemerdekaan Kemerdekaan"
    ),
    Qa(
        id = "230", subject = "Geografi", level = "Tingkatan 1",
        question = "Apakah arah yang terletak bertentangan dengan timur?",
        working = "Jawapan: Barat\n\nPada mata angin utama, barat bertentangan dengan timur.",
        language = "BM", answer = "Barat",
        keywords = "arah mata angin Arah"
    ),
    Qa(
        id = "231", subject = "Geografi", level = "Tingkatan 2",
        question = "Apakah alat untuk mengukur suhu udara?",
        working = "Jawapan: Termometer\n\nTermometer digunakan untuk mengukur suhu.",
        language = "BM", answer = "Termometer",
        keywords = "cuaca iklim termometer Cuaca dan iklim"
    ),
    Qa(
        id = "232", subject = "Geografi", level = "Tingkatan 3",
        question = "Apakah maksud skala peta?",
        working = "Jawapan: Nisbah jarak pada peta kepada jarak sebenar di permukaan bumi.\n\nSkala membolehkan jarak sebenar dianggarkan daripada jarak yang diukur pada peta.",
        language = "BM", answer = "Nisbah jarak pada peta kepada jarak sebenar di permukaan bumi.",
        keywords = "skala peta Peta"
    ),
    Qa(
        id = "233", subject = "Geografi", level = "SPM",
        question = "Nyatakan satu langkah mengurangkan risiko banjir di kawasan bandar.",
        working = "Jawapan: Menyelenggara longkang dan membina sistem saliran yang berkesan.\n\nSaliran yang lancar membantu mengalirkan air hujan; perancangan guna tanah dan kawasan tadahan juga penting.",
        language = "BM", answer = "Menyelenggara longkang dan membina sistem saliran yang berkesan.",
        keywords = "spm banjir Bencana alam"
    ),
    Qa(
        id = "234", subject = "Pendidikan Islam", level = "Tingkatan 1",
        question = "Nyatakan lima Rukun Islam.",
        working = "Jawapan: Mengucap dua kalimah syahadah; solat; puasa Ramadan; zakat; haji bagi yang mampu.\n\nLima Rukun Islam ialah asas amalan dalam Islam. Haji diwajibkan bagi yang berkemampuan.",
        language = "BM", answer = "Mengucap dua kalimah syahadah; solat; puasa Ramadan; zakat; haji bagi yang mampu.",
        keywords = "rukun islam Rukun Islam"
    ),
    Qa(
        id = "235", subject = "Pendidikan Islam", level = "Tingkatan 4",
        question = "Berikan satu contoh amanah di sekolah.",
        working = "Jawapan: Menjaga barang yang dipinjam dan memulangkannya kepada pemilik.\n\nAmanah bermaksud menunaikan tanggungjawab dan menjaga hak orang lain.",
        language = "BM", answer = "Menjaga barang yang dipinjam dan memulangkannya kepada pemilik.",
        keywords = "amanah akhlak Akhlak"
    ),
    Qa(
        id = "236", subject = "Pendidikan Moral", level = "Tingkatan 1",
        question = "Berikan satu contoh amalan bertanggungjawab di rumah.",
        working = "Jawapan: Membantu melakukan kerja rumah mengikut kemampuan.\n\nTanggungjawab bermaksud melaksanakan tugas dan kewajipan dengan baik.",
        language = "BM", answer = "Membantu melakukan kerja rumah mengikut kemampuan.",
        keywords = "nilai moral tanggungjawab Nilai moral"
    ),
    Qa(
        id = "237", subject = "Pendidikan Moral", level = "SPM",
        question = "Nyatakan satu tindakan yang menunjukkan hormat terhadap agama dan budaya lain.",
        working = "Jawapan: Menghormati amalan mereka dan tidak menghina kepercayaan mereka.\n\nSikap hormat membantu mengekalkan keharmonian masyarakat majmuk.",
        language = "BM", answer = "Menghormati amalan mereka dan tidak menghina kepercayaan mereka.",
        keywords = "spm moral hormat Hormati kepelbagaian"
    ),
    Qa(
        id = "238", subject = "Fizik", level = "Tingkatan 4",
        question = "Sebuah objek berjisim 2 kg mengalami pecutan 3 m/s². Hitung daya paduan.",
        working = "Jawapan: 6 N\n\nF = ma = 2 × 3 = 6 N.",
        language = "BM", answer = "6 N",
        keywords = "fizik daya pecutan Daya dan gerakan"
    ),
    Qa(
        id = "239", subject = "Kimia", level = "Tingkatan 4",
        question = "Apakah nilai pH yang biasanya menunjukkan larutan neutral pada 25°C?",
        working = "Jawapan: pH 7\n\nPada 25°C, larutan neutral mempunyai pH 7.",
        language = "BM", answer = "pH 7",
        keywords = "kimia ph neutral Asid dan alkali"
    ),
    Qa(
        id = "240", subject = "Biologi", level = "Tingkatan 4",
        question = "Nyatakan dua bahan mentah fotosintesis.",
        working = "Jawapan: Karbon dioksida dan air\n\nDengan kehadiran cahaya dan klorofil, tumbuhan menggunakan karbon dioksida dan air untuk menghasilkan glukosa dan oksigen.",
        language = "BM", answer = "Karbon dioksida dan air",
        keywords = "biologi fotosintesis Fotosintesis"
    ),
    Qa(
        id = "241", subject = "Prinsip Perakaunan", level = "Tingkatan 4",
        question = "Lengkapkan persamaan: Aset = Liabiliti + ___.",
        working = "Jawapan: Ekuiti pemilik\n\nPersamaan perakaunan asas ialah Aset = Liabiliti + Ekuiti pemilik.",
        language = "BM", answer = "Ekuiti pemilik",
        keywords = "perakaunan aset liabiliti ekuiti Persamaan perakaunan"
    ),
    Qa(
        id = "242", subject = "Perniagaan", level = "Tingkatan 4",
        question = "Nyatakan satu tujuan menyediakan rancangan perniagaan.",
        working = "Jawapan: Merancang operasi dan menilai kebolehlaksanaan perniagaan.\n\nRancangan perniagaan menerangkan matlamat, pasaran, operasi dan anggaran kewangan.",
        language = "BM", answer = "Merancang operasi dan menilai kebolehlaksanaan perniagaan.",
        keywords = "perniagaan rancangan Keusahawanan"
    ),
    Qa(
        id = "243", subject = "Reka Bentuk dan Teknologi", level = "Tingkatan 2",
        question = "Apakah tujuan lakaran awal dalam proses reka bentuk?",
        working = "Jawapan: Menggambarkan idea awal untuk dinilai dan diperbaiki.\n\nLakaran membantu meneroka idea sebelum membina model atau produk.",
        language = "BM", answer = "Menggambarkan idea awal untuk dinilai dan diperbaiki.",
        keywords = "rbt lakaran Reka bentuk"
    ),
    Qa(
        id = "244", subject = "Asas Sains Komputer", level = "Tingkatan 3",
        question = "Apakah algoritma?",
        working = "Jawapan: Urutan langkah yang teratur untuk menyelesaikan masalah.\n\nAlgoritma menyatakan langkah penyelesaian secara jelas dan tersusun.",
        language = "BM", answer = "Urutan langkah yang teratur untuk menyelesaikan masalah.",
        keywords = "ask algoritma Algoritma"
    ),
    Qa(
        id = "245", subject = "Matematik", level = "SPM",
        question = "Cari min bagi 4, 6, 8 dan 10.",
        working = "Jawapan: 7\n\nMin = jumlah data ÷ bilangan data = (4 + 6 + 8 + 10) ÷ 4 = 28 ÷ 4 = 7.",
        language = "BM", answer = "7",
        keywords = "spm statistik min Statistik"
    ),
    Qa(
        id = "246", subject = "Sains", level = "Tingkatan 2",
        question = "Apakah organ utama yang mengepam darah ke seluruh badan?",
        working = "Jawapan: Jantung\n\nJantung mengepam darah melalui sistem peredaran darah.",
        language = "BM", answer = "Jantung",
        keywords = "organ jantung Sistem badan"
    ),
    Qa(
        id = "247", subject = "Sejarah", level = "Tingkatan 3",
        question = "Mengapakah penentangan terhadap campur tangan kuasa asing berlaku?",
        working = "Jawapan: Antara sebabnya ialah kehilangan kuasa pemerintah tempatan dan beban cukai atau peraturan baharu.\n\nJawapan bergantung pada peristiwa yang dikaji; huraikan sebab khusus dan berikan contoh yang tepat.",
        language = "BM", answer = "Antara sebabnya ialah kehilangan kuasa pemerintah tempatan dan beban cukai atau peraturan baharu.",
        keywords = "penentangan kuasa asing Pentadbiran"
    ),
    Qa(
        id = "248", subject = "Geografi", level = "Tingkatan 4",
        question = "Nyatakan satu contoh sumber tenaga boleh baharu.",
        working = "Jawapan: Tenaga suria.\n\nSumber boleh baharu dapat diperbaharui secara semula jadi, seperti suria, angin dan hidro.",
        language = "BM", answer = "Tenaga suria.",
        keywords = "tenaga boleh baharu Sumber semula jadi"
    ),
    Qa(
        id = "249", subject = "English", level = "Form 2",
        question = "What is the main idea of a paragraph?",
        working = "Jawapan: The central point or message of the paragraph.\n\nLook for the idea that most of the supporting sentences explain.",
        language = "EN", answer = "The central point or message of the paragraph.",
        keywords = "reading comprehension main idea Reading comprehension"
    ),
    Qa(
        id = "250", subject = "Bahasa Melayu", level = "Tingkatan 5",
        question = "Apakah yang perlu dikenal pasti sebelum menulis rumusan?",
        working = "Jawapan: Fokus atau tugasan rumusan dan isi-isi yang relevan dalam bahan.\n\nBaca arahan, kenal pasti fokus, pilih isi yang menepati tugasan dan tulis dengan ayat sendiri.",
        language = "BM", answer = "Fokus atau tugasan rumusan dan isi-isi yang relevan dalam bahan.",
        keywords = "rumusan fokus isi Rumusan"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DotlockApp() }
    }
}

@Composable
fun DotlockApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("dotlock_preferences", android.content.Context.MODE_PRIVATE) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Qa?>(null) }
    var tab by remember { mutableStateOf("Cari") }
    var savedIds by remember {
        mutableStateOf(preferences.getStringSet("saved_question_ids", emptySet())?.toSet() ?: emptySet())
    }

    fun updateSavedIds(next: Set<String>) {
        savedIds = next
        preferences.edit().putStringSet("saved_question_ids", next.toSet()).apply()
    }

    val filtered = remember(query, tab, savedIds) {
        val base = if (tab == "Disimpan") seedQuestions.filter { it.id in savedIds } else seedQuestions
        if (query.isBlank()) base else base.filter {
            val haystack = "${it.subject} ${it.level} ${it.question} ${it.keywords} ${it.answer} ${it.language} ${it.working}".lowercase()
            query.lowercase().trim().split(Regex("\\s+")).any { term -> haystack.contains(term) }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, background = Pale,
            surface = Color.White, onSurface = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Pale) {
            if (selected != null) {
                QuestionDetail(
                    qa = selected!!,
                    saved = selected!!.id in savedIds,
                    onBack = { selected = null },
                    onSave = {
                        updateSavedIds(if (selected!!.id in savedIds) savedIds - selected!!.id else savedIds + selected!!.id)
                    }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxWidth().background(Ink).padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 24.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(42.dp).background(Blue, RoundedCornerShape(13.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("D", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.width(11.dp))
                            Text("dot", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("lock", color = Blue, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Surface(color = Color(0xFF222833), shape = RoundedCornerShape(50)) {
                                Text("MVP 0.2", color = Color(0xFFCBD5E1), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Text("Belajar, satu soalan pada satu masa.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                        Spacer(Modifier.height(7.dp))
                        Text("Cari jawapan dan fahami jalan kerjanya.", color = Color(0xFFB9C2D0), fontSize = 14.sp)
                    }

                    Column(Modifier.weight(1f).padding(horizontal = 18.dp)) {
                        Spacer(Modifier.height(18.dp))
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Cari soalan, topik atau kata kunci…", fontSize = 14.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari", tint = Blue) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = Color.White,
                                focusedContainerColor = Color.White,
                                unfocusedBorderColor = Color(0xFFE1E6EF),
                                focusedBorderColor = Blue
                            )
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = tab == "Cari", onClick = { tab = "Cari" }, label = { Text("Semua soalan") })
                            FilterChip(selected = tab == "Disimpan", onClick = { tab = "Disimpan" }, label = { Text("Disimpan (${savedIds.size})") })
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (query.isBlank()) "Contoh soalan" else "Hasil carian", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Spacer(Modifier.weight(1f))
                            Text("${filtered.size} soalan", color = Muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        if (filtered.isEmpty()) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 34.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = Muted, modifier = Modifier.size(34.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Tiada padanan ditemui", fontWeight = FontWeight.SemiBold)
                                    Text("Cuba kata kunci lain atau semak ejaan.", color = Muted, fontSize = 13.sp)
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                                items(filtered, key = { it.id }) { qa ->
                                    QuestionCard(qa = qa, onClick = { selected = qa })
                                }
                            }
                        }
                    }

                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(
                            selected = tab == "Cari", onClick = { tab = "Cari" },
                            icon = { Icon(Icons.Default.Search, contentDescription = null) }, label = { Text("Cari") }
                        )
                        NavigationBarItem(
                            selected = tab == "Disimpan", onClick = { tab = "Disimpan" },
                            icon = { Icon(Icons.Default.BookmarkBorder, contentDescription = null) }, label = { Text("Disimpan") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuestionCard(qa: Qa, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color(0xFFEAF1FF), shape = RoundedCornerShape(7.dp)) {
                    Text(qa.subject, color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                }
                Spacer(Modifier.width(7.dp))
                Text(qa.level, color = Muted, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFF9AA4B2), modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(qa.question, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Jawapan: ", color = Muted, fontSize = 12.sp)
                Text(qa.answer, color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text("Lihat jalan kerja  ›", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun QuestionDetail(qa: Qa, saved: Boolean, onBack: () -> Unit, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Ink).padding(horizontal = 18.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Kembali", tint = Color.White) }
            Spacer(Modifier.width(6.dp))
            Text("Butiran soalan", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSave) { Icon(Icons.Default.BookmarkBorder, contentDescription = if (saved) "Disimpan" else "Simpan", tint = if (saved) Blue else Color.White) }
        }
        Column(Modifier.weight(1f).padding(20.dp)) {
            Surface(color = Color(0xFFEAF1FF), shape = RoundedCornerShape(8.dp)) {
                Text("${qa.subject}  •  ${qa.level}", color = Blue, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("SOALAN", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(7.dp))
            Text(qa.question, fontSize = 21.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
            Spacer(Modifier.height(22.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(17.dp)) {
                    Text("JAWAPAN AKHIR", color = Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(7.dp))
                    Text(qa.answer, fontWeight = FontWeight.Bold, fontSize = 23.sp)
                }
            }
            Spacer(Modifier.height(15.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(17.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = Blue)
                        Spacer(Modifier.width(8.dp))
                        Text("Jalan kerja", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(qa.working, fontSize = 15.sp, lineHeight = 24.sp)
                }
            }
            Spacer(Modifier.height(15.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF1FF))) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Bahasa", color = Blue, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text(if (qa.language == "BM") "Bahasa Melayu" else "English", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Default.BookmarkBorder, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (saved) "Buang daripada Disimpan" else "Simpan soalan")
            }
        }
    }
}
