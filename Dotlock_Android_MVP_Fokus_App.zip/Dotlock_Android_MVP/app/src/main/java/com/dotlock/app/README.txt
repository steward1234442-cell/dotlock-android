Kod sumber aplikasi Dotlock berada dalam MainActivity.kt.
