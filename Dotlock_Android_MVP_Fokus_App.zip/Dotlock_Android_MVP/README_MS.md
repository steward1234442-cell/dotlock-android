# Dotlock Android MVP — Bank Soalan T1 hingga SPM

## Kandungan semasa
Bank soalan awal mengandungi 50 soalan latihan asli merentas Tingkatan 1–5 dan persediaan SPM, termasuk Matematik, Sains, Bahasa Melayu, Bahasa Inggeris, Sejarah, Geografi, Pendidikan Islam, Pendidikan Moral serta beberapa subjek elektif (Fizik, Kimia, Biologi, Prinsip Perakaunan, Perniagaan, RBT dan ASK).

## Fail data
`Dotlock_Bank_Soalan_T1-SPM.csv` mempunyai lajur:
`ID, Subjek, Tingkatan, Topik, Soalan, Jawapan_Akhir, Jalan_Kerja, Bahasa, Kata_Kunci`

Data yang sama turut dimasukkan ke dalam senarai contoh aplikasi Android dalam `MainActivity.kt`.

## Had penting
Ini ialah bank soalan permulaan, bukan liputan lengkap semua topik atau skema rasmi KPM/SPM. Kandungan ialah latihan contoh asli; semak dengan buku teks dan dokumen kurikulum terkini sebelum digunakan sebagai sumber rasmi. Beberapa jawapan berbentuk penerangan menerima variasi jawapan munasabah.

## Cara membuka projek
1. Ekstrak ZIP.
2. Buka folder projek di Android Studio.
3. Tunggu Gradle sync selesai, kemudian jalankan pada emulator atau telefon Android.
4. Projek belum diuji binaan dalam persekitaran Android Studio di sini; mungkin perlu pelarasan versi Gradle/SDK mengikut pemasangan anda.

## Belum tersedia
- Penyegerakan automatik dengan Google Sheets.
- Penyimpanan kekal soalan tersimpan.
- Akaun pengguna dan pembayaran langganan.
- AI, OCR/kamera dan penerbitan Google Play.


## Fokus pembangunan sekarang
Keutamaan ialah menyiapkan pengalaman aplikasi Android dahulu, bukan menambah subjek. Versi kod semasa menyimpan senarai soalan bertanda dalam storan setempat telefon supaya pilihan itu kekal selepas aplikasi ditutup dan dibuka semula. Data soalan masih dipakejkan bersama aplikasi; Google Sheets belum disegerakkan secara langsung.
